package com.jobportal.resource;

import org.springframework.stereotype.Component;

@Component
public class UserSkillResource {

}
